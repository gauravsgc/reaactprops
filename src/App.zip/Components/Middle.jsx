import React from 'react'

export default function Middle() {
  return (
    <div>
      this is my middle component
    </div>
  )
}
